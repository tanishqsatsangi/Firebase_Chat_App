package com.goldenbirds.firebasechatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.goldenbirds.firebasechatapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;

public class GroupChatActivity extends AppCompatActivity implements PopupFragment.popupinteerface {

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    DatabaseReference dbr, databaseReference;
    ArrayList<MessageModel> msglist = new ArrayList<>();
    RecyclerView msglistview;
    MediaRecorder mRecorder = null;
    String mFileName = null, filepath = "";
    EditText msget;
    CroupChatAdapter adapter;
    ImageView voicebtn;
    CardView voicerecord;
    private FirebaseAuth mAuth;
    TextView sendvoice, cancelvoice;
    String voiceid = "";
    FragmentManager fm;
    Fragment fragment;
    CroupChatAdapter chatRecyclerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);


        mFileName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/ChatApp";
        Log.i("chatactivity", "" + mFileName);
        intializewidget();
        Intent i = getIntent();
        String chatid = i.getStringExtra("chatid");
        //connect with firebase to check msg
        checkmsg();
        msget.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (msglist.size() > 1)
                        msglistview.smoothScrollToPosition(msglist.size() - 1);
                }
            }
        });
        findViewById(R.id.sendbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = msget.getText().toString();
                if (msg.equals("") || msg.equals(" ")) {
                    Toast.makeText(getApplicationContext(), "Please type a msg", Toast.LENGTH_SHORT).show();
                } else {
                    msget.getText().clear();
                    MessageModel message = new MessageModel(mAuth.getUid(), "Name", msg.trim(), "time", "sent");
                    uploadmsg(message);
                }
            }
        });

        voicebtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //check permission
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    verifyStoragePermissions(GroupChatActivity.this);
                    startRecording();
                    msget.setVisibility(View.INVISIBLE);
                    voicerecord.setVisibility(View.VISIBLE);
                } else if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    stopRecording();
                }
                return true;
            }
        });
        sendvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadvoice();
                voicerecord.setVisibility(View.INVISIBLE);
                msget.setVisibility(View.VISIBLE);
            }
        });
        cancelvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                voicerecord.setVisibility(View.INVISIBLE);
                msget.setVisibility(View.VISIBLE);
            }
        });
    }

    public void intializewidget() {
        voicebtn = findViewById(R.id.voicbtn);
        voicerecord = findViewById(R.id.voicerecord_view);
        sendvoice = findViewById(R.id.text_send);
        cancelvoice = findViewById(R.id.text_cancel);
        msget = findViewById(R.id.msg_et);
        msglistview = findViewById(R.id.chatlistview);
        adapter = new CroupChatAdapter(GroupChatActivity.this, msglist);
        msglistview.setHasFixedSize(true);
        msglistview.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerAdapter = new CroupChatAdapter(GroupChatActivity.this, msglist);
        msglistview.setAdapter(chatRecyclerAdapter);
        mAuth = FirebaseAuth.getInstance();
        Intent i = getIntent();
        String chatid = i.getStringExtra("chatid");
        databaseReference = FirebaseDatabase.getInstance().getReference("Chats").child("chatid");
    }

    @Override
    public void onBackPressed() {
        if (fragment!=null){
            getSupportFragmentManager().beginTransaction().remove(fragment).commit();
        }
        super.onBackPressed();
    }

    public void checkmsg() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                msglist.clear();
                for (DataSnapshot postsnapshot : dataSnapshot.getChildren()) {
                    MessageModel cuurentnode = postsnapshot.getValue(MessageModel.class);
                    msglist.add(cuurentnode);

                }
                adapter = new CroupChatAdapter(GroupChatActivity.this, msglist);
                //  msglistview.setAdapter(adapter);
                //  msglistview.setSelection(msglistview.getAdapter().getCount() - 1);
                chatRecyclerAdapter.notifyDataSetChanged();
                if(msglist.size()>=1){
                    msglistview.smoothScrollToPosition(msglist.size() - 1);
                }
                Log.i("test", "" + msglist.size());
                Log.i("chatactivity", "" + msglist);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    private void startRecording() {

        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        Log.i("chatactivity", "in start recording " + mFileName);
        File dir = new File(mFileName);
        if (!dir.exists())
            dir.mkdirs();
        String myfile = mFileName + "/audio.3gp";
        filepath = myfile;
        mRecorder.setOutputFile(myfile);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mRecorder.prepare();
            mRecorder.start();
        } catch (Exception e) {
            Log.i("chatactivity", "failed" + e.getMessage());
        }

    }

    private void stopRecording() {
        mRecorder.stop();
        mRecorder.release();
        mRecorder = null;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.attachment:
                fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                fragment = new PopupFragment();
                ft.add(R.id.attachment_fl, fragment, "First");
                ft.commit();
                break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }

    public void uploadmsg(MessageModel m) {
        databaseReference.push().setValue(m);
    }

    //popupfragment interface methods
    @Override
    public void sendimg(Uri uri) {
      FirebaseAsync firebaseAsync = new FirebaseAsync();
        firebaseAsync.execute(uri);
        getSupportFragmentManager().beginTransaction().remove(fragment).commit();

    }

    @Override
    public void sendvideo(Uri uri) {
        VideoUploadsync async=new VideoUploadsync();
        async.execute(uri);
        getSupportFragmentManager().beginTransaction().remove(fragment).commit();
    }

    @Override
    public void senddoc(Uri uri) {
        getSupportFragmentManager().beginTransaction().remove(fragment).commit();
       DocUploadsync async=new DocUploadsync();
        async.execute(uri);
    }

    @Override
    public void closepopup() {
        getSupportFragmentManager().beginTransaction().remove(fragment).commit();

    }
    //Async class to get dat


    private String getFileExtension(Uri uri) {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(uri));
    }

    public void uploadvoice() {
        if (filepath != null) {
            Uri uri = Uri.fromFile(new File(filepath));
            Log.i("chatactivity", "uir " + uri);

            voiceid = UUID.randomUUID() + "audio.3gp";
            final StorageReference filerefence = FirebaseStorage.getInstance().getReference("Chats/").child("Voice/").child(voiceid);
            filerefence.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    //get a model data nad upload it to db
                    MessageModel mediamsg = new MessageModel(
                            FirebaseAuth.getInstance().getCurrentUser().getUid(), "name", "time", "sent", "" + voiceid, "voice"
                    );
                    databaseReference.child("chatid").setValue(mediamsg);
                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.i("ChatActivity", "error in sending voice" + e.getMessage());
                        }
                    });

        }
    }


    //Async to upload image
    class FirebaseAsync extends AsyncTask<Uri, Void, Void> {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        String msgid = databaseReference.push().getKey();

        @Override
        protected Void doInBackground(Uri... uris) {

            Uri imageurl = uris[0];
            if (imageurl != null) {
                final String imagelink = "" + msgid + mAuth.getUid() + "." + getFileExtension(imageurl);
                final StorageReference filerefence = FirebaseStorage.getInstance().getReference("Chats/").child("Img/").child(imagelink);
                filerefence.putFile(imageurl).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        //get a model data nad upload it to db
                        MessageModel mediamsg = new MessageModel(
                                FirebaseAuth.getInstance().getCurrentUser().getUid(), "name", time, "sent", "" + imagelink, "img");
                        databaseReference.child(msgid).setValue(mediamsg);
                    }
                })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
            return null;
        }
    }

    class VideoUploadsync extends AsyncTask<Uri, Void, Void> {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        String msgid = databaseReference.push().getKey();

        @Override
        protected Void doInBackground(Uri... uris) {

            Uri videourl = uris[0];
            if (videourl != null) {
                final String videolink = "" + msgid + mAuth.getUid() + "." + getFileExtension(videourl);
                final StorageReference filerefence = FirebaseStorage.getInstance().getReference("Chats/").child("Video/").child(videolink);
                filerefence.putFile(videourl).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        //get a model data nad upload it to db
                        MessageModel mediamsg = new MessageModel(
                                FirebaseAuth.getInstance().getCurrentUser().getUid(), "name", time, "sent", "" + videolink, "video");
                        databaseReference.child(msgid).setValue(mediamsg);
                    }
                })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
            return null;
        }
    }

    class DocUploadsync extends AsyncTask<Uri, Void, Void> {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        String msgid = databaseReference.push().getKey();

        @Override
        protected Void doInBackground(Uri... uris) {

            Uri docurl = uris[0];
            if (docurl != null) {
                final String doclink = "" + msgid + mAuth.getUid() + "." + getFileExtension(docurl);
                final StorageReference filerefence = FirebaseStorage.getInstance().getReference("Chats/").child("Video/").child(doclink);
                filerefence.putFile(docurl).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        //get a model data nad upload it to db
                        MessageModel mediamsg = new MessageModel(
                                FirebaseAuth.getInstance().getCurrentUser().getUid(), "name", time, "sent", "" + doclink, "doc");
                        databaseReference.child(msgid).setValue(mediamsg);
                    }
                })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
            return null;
        }
    }
}

