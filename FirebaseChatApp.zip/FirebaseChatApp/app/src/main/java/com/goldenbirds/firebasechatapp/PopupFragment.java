package com.goldenbirds.firebasechatapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import static android.app.Activity.RESULT_OK;



public class PopupFragment extends Fragment {
    public static final int REQUEST_CODE_IMG = 1;
    public static final int REQUEST_CODE_VIDEO = 2;
    public static final int REQUEST_CODE_DOC = 3;
    public PopupFragment() {
        // Required empty public constructor
    }

    popupinteerface popupif;
    TextView closepopup;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v= inflater.inflate(R.layout.fragment_popup, container, false);
        ImageView imgicon,videoicon,docicon;
        imgicon=v.findViewById(R.id.add_img);
        videoicon=v.findViewById(R.id.add_video);
        docicon=v.findViewById(R.id.add_doc);
        closepopup=v.findViewById(R.id.closepopup);
        closepopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        imgicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                Intent i = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, REQUEST_CODE_IMG);
            }
        });
        videoicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(intent, REQUEST_CODE_VIDEO);
            }
        });
        docicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "Pick a file"), REQUEST_CODE_DOC);

            }
        });
        closepopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupif=(popupinteerface)getActivity();
                popupif.closepopup();
            }
        });

        return  v;
    }



    //handle result set it to the view pager adapter
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_IMG && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                popupif=(popupinteerface)getActivity();
                popupif.sendimg(uri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
       else if (requestCode == REQUEST_CODE_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                popupif=(popupinteerface)getActivity();
                popupif.sendvideo(uri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        else if (requestCode == REQUEST_CODE_DOC && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                popupif=(popupinteerface)getActivity();
                popupif.senddoc(uri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }

    public  interface popupinteerface{
        public void sendimg(Uri uri);
        public void sendvideo(Uri uri);
        public  void senddoc(Uri uri);
        public  void closepopup();
    }
}
