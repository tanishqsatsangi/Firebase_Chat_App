package com.goldenbirds.firebasechatapp;

public class HomeChatModel {
    String chatname = "";
    String chatid = "";
    String lastmsg = "";
    String time = "";
    String chattype = "";
    String groupimg = "";

    public HomeChatModel() {
    }

    public HomeChatModel(String chatname, String chatid, String lastmsg, String time, String chattype, String groupimg) {
        this.chatname = chatname;
        this.chatid = chatid;
        this.lastmsg = lastmsg;
        this.time = time;
        this.chattype = chattype;
        this.groupimg = groupimg;
    }

    public HomeChatModel(String chatname, String lastmsg, String time) {
        this.chatname = chatname;
        this.lastmsg = lastmsg;
        this.time = time;
    }

    public String getChatid() {
        return chatid;
    }

    public String getGroupimg() {
        return groupimg;
    }

    public String getChattype() {
        return chattype;
    }

    public String getChatname() {
        return chatname;
    }

    public String getLastmsg() {
        return lastmsg;
    }

    public String getTime() {
        return time;
    }
}
