package com.goldenbirds.firebasechatapp;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class HomeChatListAdapter  extends BaseAdapter {

    Context mcontext;
    ArrayList<HomeChatModel> chatlist;
    public HomeChatListAdapter(){
        //empty constructor
    }
    public HomeChatListAdapter(Context context, ArrayList<HomeChatModel> al){
        mcontext=context;
        chatlist=al;
    }


    @Override
    public int getCount() {
        return chatlist.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        if(convertView==null){
            convertView= LayoutInflater.from(parent.getContext()).inflate(R.layout.home_listview_item_layout,parent,false);
             HomeChatModel currentpos=chatlist.get(position);
            TextView chatname,chatmsg;
            TextView time;
            final ImageView chatimg;
            chatname=convertView.findViewById(R.id.name_tv);
            chatmsg=convertView.findViewById(R.id.message_tv);
            time=convertView.findViewById(R.id.time_tv);
            chatimg=convertView.findViewById(R.id.avatarimg);
            chatname.setText(""+currentpos.getChatname());
            chatmsg.setText(""+currentpos.getLastmsg());
            time.setText(""+currentpos.getTime());
            if(currentpos.getGroupimg().equals("")){

            }
            else{
                StorageReference ref= FirebaseStorage.getInstance().getReference("Avatar/").child(currentpos.getGroupimg());
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Glide.with(parent.getContext()).load(uri).into(chatimg);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                    }
                });
            }
            //add data to the adapter and display ir
        }
        return convertView;
    }
}
