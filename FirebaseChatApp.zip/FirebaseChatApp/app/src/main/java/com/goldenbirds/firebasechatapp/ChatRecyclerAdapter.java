package com.goldenbirds.firebasechatapp;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;
import java.util.ArrayList;

public class ChatRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
    Context context;
    ArrayList<MessageModel> chatlist=new ArrayList<>();
    StorageReference imgref,videoref,audioref;
    Uri videouri;
        int inglaterecivedlayout=0,inflatesendlayout=1;
    public ChatRecyclerAdapter() {
        //required empty constructor
    }

    public ChatRecyclerAdapter(Context context, ArrayList<MessageModel> chatlist) {
        this.context = context;
        this.chatlist = chatlist;
        imgref= FirebaseStorage.getInstance().getReference("Chats/").child("Img/");
        videoref=FirebaseStorage.getInstance().getReference("Chats/").child("Video/");
       audioref= FirebaseStorage.getInstance().getReference("Chats/").child("Voice/");
    }


    @Override
    public int getItemViewType(int position) {
            MessageModel item=chatlist.get(position);
            if(item.getSenderid().equals( FirebaseAuth.getInstance().getUid())){
                return inflatesendlayout;
            }
            else{
                return  inglaterecivedlayout;
            }
       // return super.getItemViewType(position);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      View v;
       if(viewType==inflatesendlayout){
           v= LayoutInflater.from(parent.getContext()).inflate(R.layout.msg_layout,parent,false);
            return new ViewHolderRight(v);
       }
       else{
           v= LayoutInflater.from(parent.getContext()).inflate(R.layout.recieved_msg_layout,parent,false);
            return  new ViewHolderleft(v);
       }

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        final MessageModel item=chatlist.get(position);
        if(item.getSenderid().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){
            final ViewHolderRight holderRight=(ViewHolderRight)holder;
                holderRight.msglayout.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {

                        return false;
                    }
                });
            if(item.getMediatype().equals(""))
            holderRight.msgtv.setText(item.getMessage());


            else if(item.getMediatype().equals("img")){

                StorageReference ref=imgref.child(item.getMediaurl());
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        holderRight.msgtv.setVisibility(View.GONE);
                        holderRight.msgimg.setVisibility(View.VISIBLE);
                        Glide.with(context).load(uri).into(holderRight.msgimg);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("chatactivity","imgload error" +" "+item.getMediaurl()+" "+e.getMessage());

                    }
                });
                 }

           else  if(item.getMediatype().equals("video")){
                StorageReference ref=videoref.child(item.getMediaurl());
                holderRight.msgvideo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(videouri!=null){
                            Intent intent = new Intent(context, videoPlayer.class);
                            intent.putExtra("curl", videouri.toString());
                            context.startActivity(intent);
                        }

                    }
                });
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        holderRight.msgtv.setText("Video");
                        holderRight.msgvideo.setVisibility(View.VISIBLE);

                        videouri=uri;
                        holderRight.msgvideo.seekTo(1);
                        holderRight.msgvideo.setVideoURI(uri);
                        holderRight.msgvideo.seekTo(1);
                        holderRight.msgvideo.setZOrderOnTop(true);



                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("chatactivity","imgload error" +" "+item.getMediaurl()+" "+e.getMessage());

                    }
                });
            }


            else  if(item.getMediatype().equals("voice")){
                holderRight.msgtv.setVisibility(View.GONE);
                holderRight.voicelayout.setVisibility(View.VISIBLE);
                final StorageReference ref=audioref.child(item.getMediaurl());
                final MediaPlayer mp=new MediaPlayer();

                holderRight.voicelayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //start audio
                        if( mp.isPlaying()){
                            mp.stop();
                        }
                        else  {
                            ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {

                                    try {
                                        mp.setDataSource(context,uri);
                                        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                                        mp.prepare();
                                        mp.start();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(context, "error with voice msg", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });
            }

            holderRight.timetv.setText(item.getTime());
        }

        else{
            final ViewHolderleft holderleft=(ViewHolderleft) holder;
            if(item.getMediatype().equals(""))
            holderleft.msgtv.setText(item.getMessage());

            else if(item.getMediatype().equals("img")){

                StorageReference ref=imgref.child(item.getMediaurl());
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        holderleft.msgtv.setVisibility(View.GONE);
                        holderleft.msgimg.setVisibility(View.VISIBLE);
                        Glide.with(context).load(uri).into(holderleft.msgimg);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("chatactivity","imgload error" +" "+item.getMediaurl()+" "+e.getMessage());
                    }
                });
            }


            else  if(item.getMediatype().equals("video")){
                StorageReference ref=videoref.child(item.getMediaurl());
                holderleft.msgvideo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(videouri!=null){
                            Intent intent = new Intent(context, videoPlayer.class);
                            intent.putExtra("curl", videouri.toString());
                            context.startActivity(intent);
                        }
                    }
                });
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        holderleft.msgtv.setText("Video");
                        holderleft.msgvideo.setVisibility(View.VISIBLE);
                        //load video to videoview
                        Log.i("chatactivity",""+uri);
                        videouri=uri;
                        holderleft.msgvideo.setVideoURI(uri);
                        holderleft.msgvideo.seekTo(1);
                        holderleft.msgvideo.setZOrderOnTop(true);
                        holderleft.msgvideo.start();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("chatactivity","imgload error" +" "+item.getMediaurl()+" "+e.getMessage());

                    }
                });
            }

            else  if(item.getMediatype().equals("voice")){
                holderleft.msgtv.setVisibility(View.GONE);
                holderleft.voicelayout.setVisibility(View.VISIBLE);
                final StorageReference ref=audioref.child(item.getMediaurl());
                final MediaPlayer mp=new MediaPlayer();

                holderleft.voicelayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //start audio
                        if( mp.isPlaying()){
                            mp.stop();
                        }
                        else  {
                            ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {

                                    try {
                                        mp.setDataSource(context,uri);
                                        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                                        mp.prepare();
                                        mp.start();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(context, "error with voice msg", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });
            }

            holderleft.timetv.setText(item.getTime());


        }

    }

    @Override
    public int getItemCount() {
        return chatlist.size();
    }

    public class ViewHolderleft extends RecyclerView.ViewHolder{
            TextView msgtv,timetv;
            ImageView msgimg;
            VideoView msgvideo;
            LinearLayout voicelayout;
            ImageView voiceplaybtn;
        public ViewHolderleft(@NonNull View itemView) {
            super(itemView);
            msgtv=itemView.findViewById(R.id.msg_tv);
            timetv=itemView.findViewById(R.id.timetv);
            msgimg=itemView.findViewById(R.id.msg_imgv);
            msgvideo=itemView.findViewById(R.id.msg_videov);
            voicelayout=itemView.findViewById(R.id.msg_voicelayout);
            voiceplaybtn=itemView.findViewById(R.id.play_audio_icon);
        }
    }

    public  class  ViewHolderRight extends  RecyclerView.ViewHolder{
        TextView msgtv,timetv;
        ImageView msgimg;
        VideoView msgvideo;
        RelativeLayout msglayout;
        LinearLayout voicelayout;
        ImageView voiceplaybtn;
        public ViewHolderRight(@NonNull View itemView) {
            super(itemView);
            msgtv=itemView.findViewById(R.id.msg_tv);
            timetv=itemView.findViewById(R.id.timetv);
            msgimg=itemView.findViewById(R.id.msg_imgv);
            msgvideo=itemView.findViewById(R.id.msg_videov);
            voicelayout=itemView.findViewById(R.id.msg_voicelayout);
            voiceplaybtn=itemView.findViewById(R.id.play_audio_icon);
        msglayout=itemView.findViewById(R.id.msglayout);
        }
    }
}
