package com.goldenbirds.firebasechatapp;

public class MessageModel {
        String senderid;
        String  name;
        String  message;
        String time;
        String status;
        String mediaurl="";
        String mediatype="";
    public MessageModel() {
    }

    public MessageModel(String senderid, String name, String time, String status, String mediaurl, String mediatype) {
        this.senderid = senderid;
        this.name = name;
        this.time = time;
        this.status = status;
        this.mediaurl = mediaurl;
        this.mediatype = mediatype;
    }

    public MessageModel(String senderid, String name, String message, String time, String status) {
        this.senderid = senderid;
        this.name = name;
        this.message = message;
        this.time = time;
        this.status=status;
    }

    public String getMediaurl() {
        return mediaurl;
    }

    public String getMediatype() {
        return mediatype;
    }

    public String getSenderid() {
        return senderid;
    }

    public String getName() {
        return name;
    }

    public String getMessage() {
        return message;
    }

    public String getStatus() {
        return status;
    }

    public String getTime() {
        return time;
    }
}