package com.goldenbirds.firebasechatapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {
    ListView chatslistview;
    DatabaseReference databaseReference;
    ArrayList<HomeChatModel> chatlist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        FirebaseAuth mauth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child("IjuvF0Lhf2Y8YJA5lSORrBV4npo2");
        chatslistview = findViewById(R.id.listview);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chatlist.clear();
                for (DataSnapshot postsnapshot : dataSnapshot.getChildren()) {
                    HomeChatModel cuurentnode = postsnapshot.getValue(HomeChatModel.class);
                    Log.i("chatactivity",""+cuurentnode.getChatid());
                    chatlist.add(cuurentnode);
                }
                Log.i("chatactivity",""+chatlist.size());
                HomeChatListAdapter adapter = new HomeChatListAdapter(HomeActivity.this, chatlist);
                chatslistview.setAdapter(adapter);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        Log.i("chatactivity",""+chatlist.size());
        HomeChatListAdapter adapter = new HomeChatListAdapter(HomeActivity.this, chatlist);
        chatslistview.setAdapter(adapter);


        chatslistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //start activity and pass the chat id to it
                HomeChatModel item=chatlist.get(position);
                //check for chatype
                if (item.getChattype().equals("group")) {
                    Intent intent = new Intent(HomeActivity.this, GroupChatActivity.class);
                    intent.putExtra("chatid", ""+item.getChatid());
                    intent.putExtra("chatname", ""+item.getChatname());
                    //    startActivity(new Intent(HomeActivity.this,ChatActivity.class));
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(HomeActivity.this, ChatActivity.class);
                    intent.putExtra("chatid", "chatid");
                    intent.putExtra("chatname", "Name");
                    //  startActivity(new Intent(HomeActivity.this,ChatActivity.class));
                    startActivity(intent);
                }
            }
        });

        findViewById(R.id.fabaddbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, AddNewActivity.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile:
                //open user profile
                startActivity(new Intent(HomeActivity.this, UserProfileActivity.class));
                break;
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(HomeActivity.this, MainActivity.class));
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}
