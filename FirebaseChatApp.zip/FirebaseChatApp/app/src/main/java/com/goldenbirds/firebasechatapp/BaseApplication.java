package com.goldenbirds.firebasechatapp;

public class BaseApplication {

}
